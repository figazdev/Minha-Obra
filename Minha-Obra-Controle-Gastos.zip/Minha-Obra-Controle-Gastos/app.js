(() => {
  "use strict";

  const DATA_URL = "./data/gastos.json";
  const CONFIG_KEY = "minhaObra.githubConfig";
  const TOKEN_KEY = "minhaObra.githubToken";
  const PIN_HASH =
    "74a37b8f2a1659c62ea40a35d86d0a2d921a63db0627751a75f6f09d24bffb44";

  const CATEGORIES = {
    material: {
      label: "Material",
      color: "#27675d",
      background: "#eef6f2",
    },
    mao_de_obra: {
      label: "Mão de obra",
      color: "#527990",
      background: "#e8f0f4",
    },
    frete: {
      label: "Frete",
      color: "#c8754f",
      background: "#f8e9e2",
    },
    ferramentas: {
      label: "Ferramentas",
      color: "#9a6f23",
      background: "#f8eedb",
    },
    documentacao: {
      label: "Taxas e documentação",
      color: "#77649a",
      background: "#f0ecf7",
    },
    outros: {
      label: "Outros",
      color: "#697470",
      background: "#eff1ef",
    },
  };

  const DEFAULT_DATA = {
    schemaVersion: 1,
    project: {
      name: "Minha Obra",
      budget: 0,
      startedAt: "",
    },
    expenses: [],
    updatedAt: null,
  };

  const state = {
    data: clone(DEFAULT_DATA),
    isEditing: false,
    isDirty: false,
    remoteSha: null,
    deleteId: null,
    pendingPinAction: null,
    lastFocusedElement: null,
  };

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];

  const elements = {
    brandProjectName: $("#brandProjectName"),
    modeBadge: $("#modeBadge"),
    modeBadgeText: $("#modeBadgeText"),
    adminButton: $("#adminButton"),
    syncBanner: $("#syncBanner"),
    publishButton: $("#publishButton"),
    totalValue: $("#totalValue"),
    totalHint: $("#totalHint"),
    monthValue: $("#monthValue"),
    monthHint: $("#monthHint"),
    materialsValue: $("#materialsValue"),
    materialsHint: $("#materialsHint"),
    laborValue: $("#laborValue"),
    laborHint: $("#laborHint"),
    budgetContent: $("#budgetContent"),
    categoryBars: $("#categoryBars"),
    resultsSummary: $("#resultsSummary"),
    expensesTable: $("#expensesTable"),
    lastUpdateText: $("#lastUpdateText"),
    searchInput: $("#searchInput"),
    monthFilter: $("#monthFilter"),
    categoryFilter: $("#categoryFilter"),
    sortFilter: $("#sortFilter"),
    expenseModal: $("#expenseModal"),
    expenseForm: $("#expenseForm"),
    expenseModalTitle: $("#expenseModalTitle"),
    saveExpenseButton: $("#saveExpenseButton"),
    projectModal: $("#projectModal"),
    projectForm: $("#projectForm"),
    adminModal: $("#adminModal"),
    adminForm: $("#adminForm"),
    adminError: $("#adminError"),
    connectButton: $("#connectButton"),
    pinModal: $("#pinModal"),
    pinForm: $("#pinForm"),
    pinInput: $("#pinInput"),
    pinModalTitle: $("#pinModalTitle"),
    pinMessage: $("#pinMessage"),
    pinError: $("#pinError"),
    confirmPinButton: $("#confirmPinButton"),
    confirmDialog: $("#confirmDialog"),
    toastRegion: $("#toastRegion"),
  };

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function safeText(value, maxLength = 300) {
    return String(value ?? "").trim().slice(0, maxLength);
  }

  function normalizeData(input) {
    const source = input && typeof input === "object" ? input : {};
    const projectSource =
      source.project && typeof source.project === "object" ? source.project : {};
    const expensesSource = Array.isArray(source.expenses) ? source.expenses : [];

    const expenses = expensesSource
      .map((expense, index) => {
        const value = Number(expense?.value);
        const date = /^\d{4}-\d{2}-\d{2}$/.test(String(expense?.date ?? ""))
          ? String(expense.date)
          : todayISO();
        const category = CATEGORIES[expense?.category]
          ? expense.category
          : "outros";

        return {
          id:
            safeText(expense?.id, 80) ||
            `legacy-${index}-${date.replaceAll("-", "")}`,
          date,
          category,
          description: safeText(expense?.description, 100) || "Gasto sem descrição",
          value: Number.isFinite(value) && value > 0 ? roundMoney(value) : 0,
          supplier: safeText(expense?.supplier, 80),
          paymentMethod: safeText(expense?.paymentMethod, 40),
          receipt: safeText(expense?.receipt, 80),
          notes: safeText(expense?.notes, 280),
          createdAt: safeText(expense?.createdAt, 40) || null,
          updatedAt: safeText(expense?.updatedAt, 40) || null,
        };
      })
      .filter((expense) => expense.value > 0);

    const budget = Number(projectSource.budget);

    return {
      schemaVersion: 1,
      project: {
        name: safeText(projectSource.name, 60) || "Minha Obra",
        budget: Number.isFinite(budget) && budget > 0 ? roundMoney(budget) : 0,
        startedAt: /^\d{4}-\d{2}-\d{2}$/.test(
          String(projectSource.startedAt ?? ""),
        )
          ? String(projectSource.startedAt)
          : "",
      },
      expenses,
      updatedAt: safeText(source.updatedAt, 40) || null,
    };
  }

  function escapeHTML(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function normalizeSearch(value) {
    return String(value ?? "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .trim();
  }

  function roundMoney(value) {
    return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
  }

  function sumExpenses(expenses) {
    const cents = expenses.reduce(
      (total, expense) => total + Math.round(Number(expense.value) * 100),
      0,
    );
    return cents / 100;
  }

  function formatCurrency(value) {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(Number(value) || 0);
  }

  function parseLocalDate(value) {
    const [year, month, day] = String(value).split("-").map(Number);
    return new Date(year, month - 1, day, 12, 0, 0);
  }

  function formatDate(value) {
    if (!value) return "—";
    return new Intl.DateTimeFormat("pt-BR").format(parseLocalDate(value));
  }

  function monthKey(dateString) {
    return String(dateString ?? "").slice(0, 7);
  }

  function formatMonth(value) {
    if (!/^\d{4}-\d{2}$/.test(value)) return value;
    const [year, month] = value.split("-").map(Number);
    const label = new Intl.DateTimeFormat("pt-BR", {
      month: "long",
      year: "numeric",
    }).format(new Date(year, month - 1, 1));
    return label.charAt(0).toUpperCase() + label.slice(1);
  }

  function todayISO() {
    const now = new Date();
    const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 10);
  }

  function currentMonthKey() {
    return todayISO().slice(0, 7);
  }

  function createId() {
    if (window.crypto?.randomUUID) return window.crypto.randomUUID();
    return `gasto-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  function iconMarkup(name) {
    const paths = {
      edit: '<path d="m4 16-.7 4.7L8 20l11-11-4-4zM13.5 6.5l4 4"/>',
      delete:
        '<path d="M6 7h12M9 7V4h6v3M8 7l1 13h6l1-13M11 11v5M14 11v5"/>',
      receipt:
        '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6M9 16h3"/>',
      search:
        '<circle cx="11" cy="11" r="7"/><path d="m16 16 4 4"/>',
      check: '<path d="m5 12 4 4L19 6"/>',
      warning: '<path d="M12 4 3 20h18zM12 9v5M12 17h.01"/>',
    };
    return `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${paths[name] ?? paths.check}</svg>`;
  }

  function setButtonBusy(button, busy, busyText) {
    if (!button) return;
    if (busy) {
      button.dataset.originalHtml = button.innerHTML;
      button.disabled = true;
      button.innerHTML = `<span class="spinner" style="width:16px;height:16px;margin:0;border-width:2px"></span>${escapeHTML(busyText)}`;
    } else {
      button.disabled = false;
      if (button.dataset.originalHtml) {
        button.innerHTML = button.dataset.originalHtml;
        delete button.dataset.originalHtml;
      }
    }
  }

  function showToast(title, message = "", type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast${type === "error" ? " is-error" : ""}`;
    toast.innerHTML = `
      ${iconMarkup(type === "error" ? "warning" : "check")}
      <div>
        <strong>${escapeHTML(title)}</strong>
        ${message ? `<span>${escapeHTML(message)}</span>` : ""}
      </div>
    `;
    elements.toastRegion.append(toast);
    window.setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(8px)";
      window.setTimeout(() => toast.remove(), 220);
    }, 4200);
  }

  function openModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    state.lastFocusedElement = document.activeElement;
    modal.hidden = false;
    document.body.classList.add("modal-open");
    window.setTimeout(() => {
      modal.querySelector("input:not([type='hidden']), select, button")?.focus();
    }, 20);
  }

  function closeModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    modal.hidden = true;
    if (id === "pinModal") {
      state.pendingPinAction = null;
      elements.pinForm.reset();
      elements.pinError.hidden = true;
    }
    if (!document.querySelector(".modal:not([hidden]), .confirm:not([hidden])")) {
      document.body.classList.remove("modal-open");
    }
    state.lastFocusedElement?.focus?.();
  }

  async function hashPin(value) {
    if (!window.crypto?.subtle) {
      throw new Error("Este navegador não oferece a validação segura do PIN.");
    }
    const bytes = new TextEncoder().encode(value);
    const digest = await window.crypto.subtle.digest("SHA-256", bytes);
    return [...new Uint8Array(digest)]
      .map((byte) => byte.toString(16).padStart(2, "0"))
      .join("");
  }

  function requestPin(action, title, message) {
    if (!state.isEditing || typeof action !== "function") return;
    state.pendingPinAction = action;
    elements.pinForm.reset();
    elements.pinError.hidden = true;
    elements.pinModalTitle.textContent = title;
    elements.pinMessage.textContent = message;
    openModal("pinModal");
  }

  async function handlePinSubmit(event) {
    event.preventDefault();
    const pin = elements.pinInput.value.replace(/\D/g, "").slice(0, 6);
    elements.pinInput.value = pin;

    if (pin.length !== 6) {
      elements.pinError.textContent = "Digite os 6 números do PIN.";
      elements.pinError.hidden = false;
      elements.pinInput.focus();
      return;
    }

    setButtonBusy(elements.confirmPinButton, true, "Verificando...");
    try {
      const isValid = (await hashPin(pin)) === PIN_HASH;
      if (!isValid) {
        elements.pinError.textContent = "PIN incorreto. Tente novamente.";
        elements.pinError.hidden = false;
        elements.pinInput.value = "";
        elements.pinInput.focus();
        return;
      }

      const protectedAction = state.pendingPinAction;
      state.pendingPinAction = null;
      closeModal("pinModal");
      protectedAction?.();
    } catch (error) {
      elements.pinError.textContent =
        error?.message || "Não foi possível validar o PIN.";
      elements.pinError.hidden = false;
    } finally {
      setButtonBusy(elements.confirmPinButton, false);
    }
  }

  function markDirty() {
    state.isDirty = true;
    elements.syncBanner.hidden = false;
  }

  function markClean() {
    state.isDirty = false;
    elements.syncBanner.hidden = true;
  }

  function renderMetrics() {
    const total = sumExpenses(state.data.expenses);
    const currentMonthExpenses = state.data.expenses.filter(
      (expense) => monthKey(expense.date) === currentMonthKey(),
    );
    const monthTotal = sumExpenses(currentMonthExpenses);
    const materialTotal = sumExpenses(
      state.data.expenses.filter((expense) => expense.category === "material"),
    );
    const laborTotal = sumExpenses(
      state.data.expenses.filter((expense) => expense.category === "mao_de_obra"),
    );
    const count = state.data.expenses.length;

    elements.totalValue.textContent = formatCurrency(total);
    elements.monthValue.textContent = formatCurrency(monthTotal);
    elements.materialsValue.textContent = formatCurrency(materialTotal);
    elements.laborValue.textContent = formatCurrency(laborTotal);
    elements.totalHint.textContent =
      count === 0
        ? "Nenhum gasto lançado"
        : `${count} ${count === 1 ? "lançamento" : "lançamentos"} no total`;
    elements.monthHint.textContent = formatMonth(currentMonthKey());
    elements.materialsHint.textContent = `${total ? Math.round((materialTotal / total) * 100) : 0}% do total`;
    elements.laborHint.textContent = `${total ? Math.round((laborTotal / total) * 100) : 0}% do total`;
  }

  function renderBudget() {
    const total = sumExpenses(state.data.expenses);
    const budget = Number(state.data.project.budget) || 0;

    if (!budget) {
      elements.budgetContent.innerHTML = `
        <div class="budget-empty">
          <span class="budget-empty__icon" aria-hidden="true">
            <svg viewBox="0 0 24 24"><path d="M4 7h16v11H4zM4 10h16M7 15h4"/></svg>
          </span>
          <strong>Orçamento ainda não definido</strong>
          <p>Ao informar o valor previsto, o sistema mostra quanto já foi usado e quanto ainda resta.</p>
          ${state.isEditing ? '<button class="button button--outline" type="button" data-open-project>Definir orçamento</button>' : ""}
        </div>
      `;
      return;
    }

    const remaining = roundMoney(budget - total);
    const percentage = budget > 0 ? (total / budget) * 100 : 0;
    const cappedPercentage = Math.min(Math.max(percentage, 0), 100);
    const isOver = remaining < 0;

    elements.budgetContent.innerHTML = `
      <div class="budget-stats">
        <div class="budget-stat">
          <span>Previsto</span>
          <strong>${formatCurrency(budget)}</strong>
        </div>
        <div class="budget-stat">
          <span>Utilizado</span>
          <strong>${formatCurrency(total)}</strong>
        </div>
        <div class="budget-stat">
          <span>${isOver ? "Excedido" : "Disponível"}</span>
          <strong style="color:${isOver ? "var(--red)" : "var(--green-700)"}">${formatCurrency(Math.abs(remaining))}</strong>
        </div>
      </div>
      <div class="budget-progress${isOver ? " is-over" : ""}" role="progressbar" aria-label="Percentual do orçamento utilizado" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.min(Math.round(percentage), 100)}">
        <span style="width:${cappedPercentage}%"></span>
      </div>
      <div class="budget-progress-label">
        <span>${Math.round(percentage)}% utilizado</span>
        <span>${isOver ? "Acima do previsto" : `${Math.max(0, 100 - Math.round(percentage))}% restante`}</span>
      </div>
    `;
  }

  function renderCategories() {
    const total = sumExpenses(state.data.expenses);
    const categoryTotals = Object.entries(CATEGORIES)
      .map(([key, details]) => ({
        key,
        ...details,
        value: sumExpenses(
          state.data.expenses.filter((expense) => expense.category === key),
        ),
      }))
      .filter((category) => category.value > 0)
      .sort((a, b) => b.value - a.value);

    if (!categoryTotals.length) {
      elements.categoryBars.innerHTML =
        '<div class="category-empty">As categorias aparecerão aqui conforme os gastos forem adicionados.</div>';
      return;
    }

    elements.categoryBars.innerHTML = categoryTotals
      .slice(0, 5)
      .map((category) => {
        const percentage = total ? (category.value / total) * 100 : 0;
        return `
          <div class="category-row" style="--bar-color:${category.color};--bar-width:${percentage}%">
            <div class="category-row__heading">
              <span class="category-row__name">
                <span class="category-row__dot"></span>
                ${escapeHTML(category.label)}
              </span>
              <span class="category-row__value">${formatCurrency(category.value)} · ${Math.round(percentage)}%</span>
            </div>
            <div class="category-row__track"><span></span></div>
          </div>
        `;
      })
      .join("");
  }

  function populateMonthFilter() {
    const currentValue = elements.monthFilter.value;
    const months = [
      ...new Set(state.data.expenses.map((expense) => monthKey(expense.date))),
    ]
      .filter(Boolean)
      .sort()
      .reverse();

    elements.monthFilter.innerHTML =
      '<option value="all">Todos os meses</option>' +
      months
        .map(
          (month) =>
            `<option value="${escapeHTML(month)}">${escapeHTML(formatMonth(month))}</option>`,
        )
        .join("");

    elements.monthFilter.value = months.includes(currentValue)
      ? currentValue
      : "all";
  }

  function filteredExpenses() {
    const term = normalizeSearch(elements.searchInput.value);
    const selectedMonth = elements.monthFilter.value;
    const selectedCategory = elements.categoryFilter.value;
    const sort = elements.sortFilter.value;

    const expenses = state.data.expenses.filter((expense) => {
      const searchable = normalizeSearch(
        [
          expense.description,
          expense.supplier,
          expense.notes,
          expense.receipt,
          expense.paymentMethod,
          CATEGORIES[expense.category]?.label,
        ].join(" "),
      );

      return (
        (!term || searchable.includes(term)) &&
        (selectedMonth === "all" || monthKey(expense.date) === selectedMonth) &&
        (selectedCategory === "all" || expense.category === selectedCategory)
      );
    });

    return expenses.sort((a, b) => {
      if (sort === "date_asc") return a.date.localeCompare(b.date);
      if (sort === "value_desc") return b.value - a.value;
      if (sort === "value_asc") return a.value - b.value;
      return b.date.localeCompare(a.date) || String(b.createdAt).localeCompare(String(a.createdAt));
    });
  }

  function categoryChip(expense) {
    const category = CATEGORIES[expense.category] ?? CATEGORIES.outros;
    return `
      <span class="category-chip" style="--chip-bg:${category.background};--chip-color:${category.color}">
        ${escapeHTML(category.label)}
      </span>
    `;
  }

  function expenseSecondaryText(expense) {
    return [expense.supplier, expense.paymentMethod, expense.receipt]
      .filter(Boolean)
      .join(" · ");
  }

  function expenseActions(expense) {
    if (!state.isEditing) return "";
    return `
      <div class="row-actions">
        <button class="row-action" type="button" data-edit-expense="${escapeHTML(expense.id)}" aria-label="Editar ${escapeHTML(expense.description)}">
          ${iconMarkup("edit")}
        </button>
        <button class="row-action row-action--delete" type="button" data-delete-expense="${escapeHTML(expense.id)}" aria-label="Excluir ${escapeHTML(expense.description)}">
          ${iconMarkup("delete")}
        </button>
      </div>
    `;
  }

  function renderExpenses() {
    const expenses = filteredExpenses();
    const count = expenses.length;
    elements.resultsSummary.textContent = `${count} ${count === 1 ? "lançamento encontrado" : "lançamentos encontrados"}`;

    if (!count) {
      const hasFilters =
        elements.searchInput.value ||
        elements.monthFilter.value !== "all" ||
        elements.categoryFilter.value !== "all";
      elements.expensesTable.innerHTML = `
        <div class="empty-state">
          <div class="empty-state__inner">
            <span class="empty-state__icon" aria-hidden="true">
              <svg viewBox="0 0 24 24">${hasFilters ? '<circle cx="11" cy="11" r="7"/><path d="m16 16 4 4"/>' : '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6M9 16h3"/>'}</svg>
            </span>
            <h3>${hasFilters ? "Nenhum resultado encontrado" : "Nenhum gasto lançado ainda"}</h3>
            <p>${hasFilters ? "Tente alterar os filtros ou o termo pesquisado." : "Quando um gasto for cadastrado, ele aparecerá aqui com todos os detalhes."}</p>
            ${state.isEditing && !hasFilters ? '<button class="button button--primary" type="button" data-new-expense>Adicionar primeiro gasto</button>' : ""}
          </div>
        </div>
      `;
      return;
    }

    const actionHeader = state.isEditing ? '<th class="col-actions"><span class="sr-only">Ações</span></th>' : "";
    const rows = expenses
      .map(
        (expense) => `
          <tr>
            <td class="col-date">${formatDate(expense.date)}</td>
            <td class="expense-description">
              <strong title="${escapeHTML(expense.description)}">${escapeHTML(expense.description)}</strong>
              <span title="${escapeHTML(expenseSecondaryText(expense))}">${escapeHTML(expenseSecondaryText(expense) || expense.notes || "Sem informação adicional")}</span>
            </td>
            <td class="col-category">${categoryChip(expense)}</td>
            <td class="col-value expense-value">${formatCurrency(expense.value)}</td>
            ${state.isEditing ? `<td class="col-actions">${expenseActions(expense)}</td>` : ""}
          </tr>
        `,
      )
      .join("");

    const mobileRows = expenses
      .map(
        (expense) => `
          <article class="mobile-expense">
            <div class="mobile-expense__top">
              <div class="mobile-expense__title">
                <strong>${escapeHTML(expense.description)}</strong>
                <span>${formatDate(expense.date)}${expense.supplier ? ` · ${escapeHTML(expense.supplier)}` : ""}</span>
              </div>
              <span class="mobile-expense__value">${formatCurrency(expense.value)}</span>
            </div>
            <div class="mobile-expense__bottom">
              ${categoryChip(expense)}
              ${expenseActions(expense)}
            </div>
          </article>
        `,
      )
      .join("");

    elements.expensesTable.innerHTML = `
      <div class="table-scroll">
        <table>
          <thead>
            <tr>
              <th class="col-date">Data</th>
              <th>Material / serviço</th>
              <th class="col-category">Categoria</th>
              <th class="col-value">Valor</th>
              ${actionHeader}
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
      <div class="mobile-expense-list">${mobileRows}</div>
    `;
  }

  function renderLastUpdate() {
    if (!state.data.updatedAt) {
      elements.lastUpdateText.textContent = "Nenhuma atualização publicada";
      return;
    }
    const date = new Date(state.data.updatedAt);
    if (Number.isNaN(date.getTime())) {
      elements.lastUpdateText.textContent = "Atualização registrada";
      return;
    }
    elements.lastUpdateText.textContent = `Última publicação em ${new Intl.DateTimeFormat(
      "pt-BR",
      {
        dateStyle: "short",
        timeStyle: "short",
      },
    ).format(date)}`;
  }

  function renderAll({ preserveMonth = false } = {}) {
    const selectedMonth = preserveMonth ? elements.monthFilter.value : "all";
    elements.brandProjectName.textContent = state.data.project.name;
    document.title = `${state.data.project.name} — Controle de Gastos`;
    renderMetrics();
    renderBudget();
    renderCategories();
    populateMonthFilter();
    if (preserveMonth) elements.monthFilter.value = selectedMonth;
    renderExpenses();
    renderLastUpdate();
    $$(".editor-only").forEach((element) => {
      element.hidden = !state.isEditing;
    });
  }

  function setEditing(enabled) {
    state.isEditing = enabled;
    elements.modeBadge.classList.toggle("is-editing", enabled);
    elements.modeBadgeText.textContent = enabled
      ? "Modo edição ativo"
      : "Visualização pública";

    if (enabled) {
      elements.adminButton.innerHTML = `
        <svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 11V7a3 3 0 0 1 5.7-1.3M6 11h12v9H6z"/></svg>
        <span class="desktop-label">Sair da edição</span>
        <span class="mobile-label">Sair</span>
      `;
    } else {
      elements.adminButton.innerHTML = `
        <svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 10V7a5 5 0 0 1 10 0v3M6 10h12v10H6z"/></svg>
        <span class="desktop-label">Modo edição</span>
        <span class="mobile-label">Editar</span>
      `;
      markClean();
      state.remoteSha = null;
      sessionStorage.removeItem(TOKEN_KEY);
    }

    renderAll({ preserveMonth: true });
  }

  function openExpenseForm(expense = null) {
    if (!state.isEditing) return;
    elements.expenseForm.reset();
    $("#expenseId").value = expense?.id ?? "";
    $("#expenseDate").value = expense?.date ?? todayISO();
    $("#expenseCategory").value = expense?.category ?? "material";
    $("#expenseDescription").value = expense?.description ?? "";
    $("#expenseValue").value = expense?.value ?? "";
    $("#expenseSupplier").value = expense?.supplier ?? "";
    $("#expensePayment").value = expense?.paymentMethod ?? "";
    $("#expenseReceipt").value = expense?.receipt ?? "";
    $("#expenseNotes").value = expense?.notes ?? "";
    elements.expenseModalTitle.textContent = expense
      ? "Editar gasto"
      : "Adicionar novo gasto";
    elements.saveExpenseButton.textContent = expense
      ? "Salvar alteração"
      : "Adicionar gasto";
    openModal("expenseModal");
  }

  function handleExpenseSubmit(event) {
    event.preventDefault();
    if (!state.isEditing) return;

    const id = safeText($("#expenseId").value, 80);
    const value = roundMoney(Number($("#expenseValue").value));
    if (!value || value <= 0) {
      $("#expenseValue").focus();
      showToast("Informe um valor válido.", "O gasto precisa ser maior que zero.", "error");
      return;
    }

    const now = new Date().toISOString();
    const existing = id
      ? state.data.expenses.find((expense) => expense.id === id)
      : null;
    const expense = {
      id: id || createId(),
      date: $("#expenseDate").value || todayISO(),
      category: CATEGORIES[$("#expenseCategory").value]
        ? $("#expenseCategory").value
        : "outros",
      description: safeText($("#expenseDescription").value, 100),
      value,
      supplier: safeText($("#expenseSupplier").value, 80),
      paymentMethod: safeText($("#expensePayment").value, 40),
      receipt: safeText($("#expenseReceipt").value, 80),
      notes: safeText($("#expenseNotes").value, 280),
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };

    if (!expense.description) {
      $("#expenseDescription").focus();
      return;
    }

    if (existing) {
      state.data.expenses = state.data.expenses.map((item) =>
        item.id === id ? expense : item,
      );
    } else {
      state.data.expenses.push(expense);
    }

    markDirty();
    closeModal("expenseModal");
    renderAll({ preserveMonth: true });
    showToast(
      existing ? "Gasto atualizado." : "Gasto adicionado.",
      "Publique as alterações para atualizar a página pública.",
    );
  }

  function openProjectForm() {
    if (!state.isEditing) return;
    $("#projectNameInput").value = state.data.project.name;
    $("#projectBudgetInput").value = state.data.project.budget || "";
    $("#projectStartInput").value = state.data.project.startedAt || "";
    openModal("projectModal");
  }

  function handleProjectSubmit(event) {
    event.preventDefault();
    const name = safeText($("#projectNameInput").value, 60);
    if (!name) return;
    const budget = roundMoney(Number($("#projectBudgetInput").value) || 0);
    state.data.project = {
      name,
      budget: Math.max(0, budget),
      startedAt: $("#projectStartInput").value || "",
    };
    markDirty();
    closeModal("projectModal");
    renderAll({ preserveMonth: true });
    showToast(
      "Dados da obra atualizados.",
      "Publique para disponibilizar a alteração.",
    );
  }

  function askDelete(id) {
    if (!state.isEditing) return;
    const expense = state.data.expenses.find((item) => item.id === id);
    if (!expense) return;
    state.deleteId = id;
    $("#confirmTitle").textContent = "Excluir este gasto?";
    $("#confirmText").textContent = `${expense.description} — ${formatCurrency(expense.value)}. A exclusão ficará pública depois da publicação.`;
    elements.confirmDialog.hidden = false;
    document.body.classList.add("modal-open");
    $("#cancelDeleteButton").focus();
  }

  function closeDeleteDialog() {
    elements.confirmDialog.hidden = true;
    state.deleteId = null;
    if (!document.querySelector(".modal:not([hidden])")) {
      document.body.classList.remove("modal-open");
    }
  }

  function confirmDelete() {
    if (!state.deleteId) return;
    state.data.expenses = state.data.expenses.filter(
      (expense) => expense.id !== state.deleteId,
    );
    markDirty();
    closeDeleteDialog();
    renderAll({ preserveMonth: true });
    showToast(
      "Gasto removido.",
      "Publique as alterações para concluir a exclusão.",
    );
  }

  function inferGitHubConfig() {
    let saved = {};
    try {
      saved = JSON.parse(localStorage.getItem(CONFIG_KEY) || "{}");
    } catch {
      saved = {};
    }

    const isGitHubPages = location.hostname.endsWith(".github.io");
    const ownerFromHost = isGitHubPages ? location.hostname.split(".")[0] : "";
    const pathParts = location.pathname.split("/").filter(Boolean);
    const repoFromPath =
      isGitHubPages && pathParts.length ? pathParts[0] : "";

    return {
      owner: safeText(saved.owner || ownerFromHost || "figazdev", 80),
      repo: safeText(saved.repo || repoFromPath || "minha-obra-gastos", 100),
      branch: safeText(saved.branch || "main", 100),
      filePath: safeText(saved.filePath || "data/gastos.json", 220),
    };
  }

  function fillAdminForm() {
    const config = inferGitHubConfig();
    $("#githubOwner").value = config.owner;
    $("#githubRepo").value = config.repo;
    $("#githubBranch").value = config.branch;
    $("#githubFilePath").value = config.filePath;
    $("#githubToken").value = sessionStorage.getItem(TOKEN_KEY) || "";
    elements.adminError.hidden = true;
  }

  function readAdminForm() {
    return {
      owner: safeText($("#githubOwner").value, 80),
      repo: safeText($("#githubRepo").value, 100),
      branch: safeText($("#githubBranch").value, 100) || "main",
      filePath:
        safeText($("#githubFilePath").value, 220).replace(/^\/+/, "") ||
        "data/gastos.json",
      token: safeText($("#githubToken").value, 500),
    };
  }

  function githubContentsUrl(config, includeRef = true) {
    const encodedPath = config.filePath
      .split("/")
      .filter(Boolean)
      .map(encodeURIComponent)
      .join("/");
    const base = `https://api.github.com/repos/${encodeURIComponent(config.owner)}/${encodeURIComponent(config.repo)}/contents/${encodedPath}`;
    return includeRef
      ? `${base}?ref=${encodeURIComponent(config.branch)}`
      : base;
  }

  function githubHeaders(token) {
    return {
      Accept: "application/vnd.github+json",
      Authorization: `Bearer ${token}`,
      "X-GitHub-Api-Version": "2022-11-28",
    };
  }

  function decodeBase64Utf8(value) {
    const binary = atob(String(value).replace(/\s/g, ""));
    const bytes = Uint8Array.from(binary, (character) =>
      character.charCodeAt(0),
    );
    return new TextDecoder().decode(bytes);
  }

  function encodeBase64Utf8(value) {
    const bytes = new TextEncoder().encode(value);
    let binary = "";
    const chunkSize = 0x8000;
    for (let index = 0; index < bytes.length; index += chunkSize) {
      binary += String.fromCharCode(
        ...bytes.subarray(index, index + chunkSize),
      );
    }
    return btoa(binary);
  }

  async function getRemoteFile(config, token) {
    const response = await fetch(githubContentsUrl(config), {
      headers: githubHeaders(token),
      cache: "no-store",
    });

    if (!response.ok) {
      let details = {};
      try {
        details = await response.json();
      } catch {
        details = {};
      }
      const error = new Error(details.message || "Não foi possível acessar o arquivo.");
      error.status = response.status;
      throw error;
    }

    const payload = await response.json();
    if (payload.type !== "file" || !payload.content || !payload.sha) {
      throw new Error("O caminho informado não corresponde a um arquivo de dados.");
    }
    return {
      sha: payload.sha,
      data: normalizeData(JSON.parse(decodeBase64Utf8(payload.content))),
    };
  }

  function adminErrorMessage(error) {
    if (error?.status === 401) {
      return "A chave foi recusada. Confira se ela está correta e ainda está válida.";
    }
    if (error?.status === 403) {
      return "A chave não tem permissão suficiente. Libere “Contents: Read and write” apenas para este repositório.";
    }
    if (error?.status === 404) {
      return "Repositório, branch ou arquivo não encontrado. Confira os quatro campos acima.";
    }
    if (error instanceof SyntaxError) {
      return "O arquivo de dados existe, mas o conteúdo não está em um formato válido.";
    }
    return error?.message || "Não foi possível conectar ao GitHub.";
  }

  async function connectAdmin(event) {
    event.preventDefault();
    const config = readAdminForm();
    if (!config.owner || !config.repo || !config.token) return;

    elements.adminError.hidden = true;
    setButtonBusy(elements.connectButton, true, "Validando...");

    try {
      const remote = await getRemoteFile(config, config.token);
      localStorage.setItem(
        CONFIG_KEY,
        JSON.stringify({
          owner: config.owner,
          repo: config.repo,
          branch: config.branch,
          filePath: config.filePath,
        }),
      );
      sessionStorage.setItem(TOKEN_KEY, config.token);
      state.data = remote.data;
      state.remoteSha = remote.sha;
      markClean();
      closeModal("adminModal");
      setEditing(true);
      showToast(
        "Modo edição ativado.",
        "As alterações só ficam públicas quando você clicar em “Publicar”.",
      );
    } catch (error) {
      elements.adminError.textContent = adminErrorMessage(error);
      elements.adminError.hidden = false;
    } finally {
      setButtonBusy(elements.connectButton, false);
    }
  }

  async function publishChanges() {
    if (!state.isEditing || !state.isDirty) return;
    const token = sessionStorage.getItem(TOKEN_KEY);
    const config = inferGitHubConfig();
    if (!token) {
      fillAdminForm();
      openModal("adminModal");
      return;
    }

    setButtonBusy(elements.publishButton, true, "Publicando...");
    try {
      const remote = await getRemoteFile(config, token);
      if (state.remoteSha && remote.sha !== state.remoteSha) {
        const overwrite = window.confirm(
          "O arquivo foi alterado em outro lugar desde que você entrou no modo edição. Deseja publicar sua versão mesmo assim?",
        );
        if (!overwrite) return;
      }

      state.data.updatedAt = new Date().toISOString();
      const content = encodeBase64Utf8(
        `${JSON.stringify(normalizeData(state.data), null, 2)}\n`,
      );
      const response = await fetch(githubContentsUrl(config, false), {
        method: "PUT",
        headers: {
          ...githubHeaders(token),
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: `Atualiza gastos da obra em ${new Intl.DateTimeFormat("pt-BR").format(new Date())}`,
          content,
          sha: remote.sha,
          branch: config.branch,
        }),
      });

      if (!response.ok) {
        let details = {};
        try {
          details = await response.json();
        } catch {
          details = {};
        }
        const error = new Error(details.message || "Falha ao publicar alterações.");
        error.status = response.status;
        throw error;
      }

      const result = await response.json();
      state.data = normalizeData(state.data);
      state.remoteSha = result.content?.sha || null;
      markClean();
      renderAll({ preserveMonth: true });
      showToast(
        "Alterações publicadas.",
        "O GitHub Pages pode levar alguns instantes para atualizar a página pública.",
      );
    } catch (error) {
      showToast("Não foi possível publicar.", adminErrorMessage(error), "error");
    } finally {
      setButtonBusy(elements.publishButton, false);
    }
  }

  function exportCSV() {
    const expenses = filteredExpenses();
    if (!expenses.length) {
      showToast(
        "Não há gastos para exportar.",
        "Altere os filtros ou adicione um lançamento.",
        "error",
      );
      return;
    }

    const rows = [
      [
        "Data",
        "Categoria",
        "Material ou serviço",
        "Fornecedor ou profissional",
        "Forma de pagamento",
        "Comprovante / referência",
        "Observação",
        "Valor (R$)",
      ],
      ...expenses.map((expense) => [
        formatDate(expense.date),
        CATEGORIES[expense.category]?.label || "Outros",
        expense.description,
        expense.supplier,
        expense.paymentMethod,
        expense.receipt,
        expense.notes,
        expense.value.toFixed(2).replace(".", ","),
      ]),
    ];
    const escapeCSV = (value) =>
      `"${String(value ?? "").replaceAll('"', '""')}"`;
    const csv = "\ufeff" + rows.map((row) => row.map(escapeCSV).join(";")).join("\r\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `gastos-${todayISO()}.csv`;
    document.body.append(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    showToast("Planilha exportada.", "O arquivo CSV foi preparado com os filtros atuais.");
  }

  async function loadPublicData() {
    elements.expensesTable.innerHTML =
      '<div class="loading-state"><div><span class="spinner"></span>Carregando gastos da obra...</div></div>';
    try {
      const response = await fetch(`${DATA_URL}?v=${Date.now()}`, {
        cache: "no-store",
      });
      if (!response.ok) throw new Error("Falha ao carregar dados.");
      state.data = normalizeData(await response.json());
    } catch {
      state.data = clone(DEFAULT_DATA);
      showToast(
        "Não foi possível carregar os dados públicos.",
        "A página iniciou vazia; tente atualizar em alguns instantes.",
        "error",
      );
    }
    renderAll();
  }

  function handleDelegatedClick(event) {
    const editButton = event.target.closest("[data-edit-expense]");
    if (editButton) {
      const expense = state.data.expenses.find(
        (item) => item.id === editButton.dataset.editExpense,
      );
      if (expense) {
        requestPin(
          () => openExpenseForm(expense),
          "Confirmar edição",
          `Digite o PIN para editar “${expense.description}”.`,
        );
      }
      return;
    }

    const deleteButton = event.target.closest("[data-delete-expense]");
    if (deleteButton) {
      const expense = state.data.expenses.find(
        (item) => item.id === deleteButton.dataset.deleteExpense,
      );
      if (expense) {
        requestPin(
          () => askDelete(expense.id),
          "Confirmar exclusão",
          `Digite o PIN para excluir “${expense.description}”.`,
        );
      }
      return;
    }

    if (event.target.closest("[data-new-expense]")) {
      requestPin(
        () => openExpenseForm(),
        "Confirmar cadastro",
        "Digite o PIN para cadastrar um novo gasto.",
      );
      return;
    }

    if (event.target.closest("[data-open-project]")) {
      openProjectForm();
    }
  }

  function bindEvents() {
    $("#newExpenseButton").addEventListener("click", () =>
      requestPin(
        () => openExpenseForm(),
        "Confirmar cadastro",
        "Digite o PIN para cadastrar um novo gasto.",
      ),
    );
    $("#newExpenseButtonSecondary").addEventListener("click", () =>
      requestPin(
        () => openExpenseForm(),
        "Confirmar cadastro",
        "Digite o PIN para cadastrar um novo gasto.",
      ),
    );
    $("#editProjectButton").addEventListener("click", openProjectForm);
    elements.expenseForm.addEventListener("submit", handleExpenseSubmit);
    elements.projectForm.addEventListener("submit", handleProjectSubmit);
    elements.adminForm.addEventListener("submit", connectAdmin);
    elements.pinForm.addEventListener("submit", handlePinSubmit);
    elements.publishButton.addEventListener("click", publishChanges);
    $("#exportButton").addEventListener("click", exportCSV);
    $("#printButton").addEventListener("click", () => window.print());

    elements.adminButton.addEventListener("click", () => {
      if (state.isEditing) {
        if (
          state.isDirty &&
          !window.confirm(
            "Existem alterações não publicadas. Deseja sair e descartá-las?",
          )
        ) {
          return;
        }
        loadPublicData();
        setEditing(false);
        showToast("Modo edição encerrado.");
      } else {
        fillAdminForm();
        openModal("adminModal");
      }
    });

    $("#toggleTokenButton").addEventListener("click", () => {
      const input = $("#githubToken");
      const show = input.type === "password";
      input.type = show ? "text" : "password";
      $("#toggleTokenButton").textContent = show ? "Ocultar" : "Mostrar";
    });

    elements.pinInput.addEventListener("input", () => {
      elements.pinInput.value = elements.pinInput.value
        .replace(/\D/g, "")
        .slice(0, 6);
      elements.pinError.hidden = true;
    });

    [elements.searchInput, elements.monthFilter, elements.categoryFilter, elements.sortFilter].forEach(
      (element) => {
        element.addEventListener(
          element === elements.searchInput ? "input" : "change",
          renderExpenses,
        );
      },
    );

    document.addEventListener("click", handleDelegatedClick);
    $$("[data-close-modal]").forEach((button) => {
      button.addEventListener("click", () =>
        closeModal(button.dataset.closeModal),
      );
    });
    $("#cancelDeleteButton").addEventListener("click", closeDeleteDialog);
    $("#confirmDeleteButton").addEventListener("click", confirmDelete);

    document.addEventListener("keydown", (event) => {
      if (event.key !== "Escape") return;
      const openModalElement = document.querySelector(".modal:not([hidden])");
      if (openModalElement) {
        closeModal(openModalElement.id);
      } else if (!elements.confirmDialog.hidden) {
        closeDeleteDialog();
      }
    });

    window.addEventListener("beforeunload", (event) => {
      if (!state.isDirty) return;
      event.preventDefault();
      event.returnValue = "";
    });
  }

  bindEvents();
  loadPublicData();
})();
