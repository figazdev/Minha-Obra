# Minha Obra — Controle de Gastos

Sistema estático e responsivo para acompanhar os gastos de uma construção. Foi preparado para funcionar gratuitamente no GitHub Pages, sem banco de dados e sem login para os visitantes.

## O que o sistema faz

- Exibe total investido, gasto do mês, materiais e mão de obra.
- Permite filtrar, pesquisar, ordenar, imprimir e exportar os lançamentos em CSV.
- Cadastra, edita e exclui gastos no modo do proprietário.
- Solicita um PIN de confirmação em cada cadastro, edição ou exclusão.
- Publica as alterações diretamente no arquivo `data/gastos.json` do repositório.
- Mantém a chave de edição apenas na aba atual do navegador; ela nunca deve ser colocada nos arquivos do site.

## Publicar no GitHub Pages

1. Crie um repositório público no GitHub.
2. Envie **todo o conteúdo desta pasta** para a raiz do repositório.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main`, a pasta `/ (root)` e salve.
6. Aguarde o GitHub informar o endereço público do site.

## Liberar edição somente para o proprietário

1. No GitHub, abra **Settings → Developer settings → Personal access tokens → Fine-grained tokens**.
2. Crie uma chave autorizada somente para o repositório do sistema.
3. Em **Repository permissions**, conceda **Contents: Read and write**.
4. No sistema publicado, clique em **Modo edição** e informe essa chave.

Depois de ativar o modo edição, o sistema também solicitará o PIN definido pelo proprietário sempre que alguém tentar cadastrar, editar ou excluir um gasto.

Use uma validade curta ou moderada para a chave. Se ela for perdida ou exposta, revogue-a imediatamente no GitHub e crie outra.

## Onde ficam os dados

Todos os lançamentos públicos ficam em `data/gastos.json`. Cada publicação feita no modo edição gera uma atualização no histórico do próprio repositório.

## Testar antes de publicar

Por segurança do navegador, não abra o `index.html` apenas com dois cliques. Use um servidor local simples ou publique diretamente no GitHub Pages. Exemplo, se já tiver Python instalado:

```bash
python -m http.server 8000
```

Depois acesse `http://localhost:8000`.
